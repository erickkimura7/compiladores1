/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiladores;

/**
 *
 * @author erickkimura
 */
public class Dados {
    	
	String L1 = "abcdefghijklmnopqrstuvwxyz";
	String L2 = "abcdefgh";
	String L3 = "ijklmnop";
	String L4 = "qrstuvwxyz";
	String N1 = "0123456789";
	String N2 = "01234";
	String N3 = "56789";
	String E1 = "!@#$%&*";
	String E2 = "!@#";
	String E3 = "$%&*";
}
